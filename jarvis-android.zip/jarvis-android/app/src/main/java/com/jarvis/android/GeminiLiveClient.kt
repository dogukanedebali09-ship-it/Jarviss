package com.jarvis.android

import android.util.Base64
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Gemini Live API (ham WebSocket) istemcisi.
 * Giriş: 16 kHz PCM. Çıkış: 24 kHz PCM. Araç çağrıları [onToolCall] ile işlenir.
 */
class GeminiLiveClient(
    private val apiKey: String,
    private val model: String,
    private val voice: String,
    private val systemPrompt: String,
    private val listener: Listener,
    private val toolCall: (name: String, args: JSONObject) -> String,
) {
    interface Listener {
        fun onReady()
        fun onAudio(pcm: ByteArray)
        fun onInterrupted()
        fun onUserText(text: String)
        fun onModelText(text: String)
        fun onTurnComplete()
        fun onClosed(reason: String)
    }

    private val http = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()
    private var ws: WebSocket? = null
    @Volatile var ready = false
        private set

    fun connect() {
        val url = "wss://generativelanguage.googleapis.com/ws/" +
            "google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=$apiKey"
        ws = http.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                webSocket.send(buildSetup().toString())
            }
            override fun onMessage(webSocket: WebSocket, text: String) = handle(text)
            override fun onMessage(webSocket: WebSocket, bytes: ByteString) = handle(bytes.utf8())
            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                webSocket.close(1000, null)
            }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                ready = false
                listener.onClosed(if (reason.isBlank()) "Bağlantı kapandı ($code)" else reason)
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                ready = false
                val code = response?.code
                val msg = when (code) {
                    400, 401, 403 -> "API anahtarı geçersiz veya yetkisiz ($code)"
                    else -> t.message ?: "Bağlantı hatası"
                }
                listener.onClosed(msg)
            }
        })
    }

    private fun buildSetup(): JSONObject {
        val fnDecls = JSONArray(Tools.declarationsJson)
        return JSONObject().put("setup", JSONObject()
            .put("model", "models/$model")
            .put("generationConfig", JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", JSONObject()
                    .put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice)))))
            .put("systemInstruction", JSONObject().put("parts",
                JSONArray().put(JSONObject().put("text", systemPrompt))))
            .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", fnDecls)))
            .put("inputAudioTranscription", JSONObject())
            .put("outputAudioTranscription", JSONObject()))
    }

    private fun handle(raw: String) {
        val msg = try { JSONObject(raw) } catch (_: Exception) { return }

        if (msg.has("setupComplete")) { ready = true; listener.onReady(); return }

        msg.optJSONObject("serverContent")?.let { sc ->
            if (sc.optBoolean("interrupted")) listener.onInterrupted()
            sc.optJSONObject("modelTurn")?.optJSONArray("parts")?.let { parts ->
                for (i in 0 until parts.length()) {
                    val data = parts.getJSONObject(i).optJSONObject("inlineData")?.optString("data")
                    if (!data.isNullOrEmpty()) listener.onAudio(Base64.decode(data, Base64.DEFAULT))
                }
            }
            sc.optJSONObject("inputTranscription")?.optString("text")
                ?.takeIf { it.isNotBlank() }?.let(listener::onUserText)
            sc.optJSONObject("outputTranscription")?.optString("text")
                ?.takeIf { it.isNotBlank() }?.let(listener::onModelText)
            if (sc.optBoolean("turnComplete")) listener.onTurnComplete()
        }

        msg.optJSONObject("toolCall")?.optJSONArray("functionCalls")?.let { calls ->
            val responses = JSONArray()
            for (i in 0 until calls.length()) {
                val c = calls.getJSONObject(i)
                val name = c.optString("name")
                val result = try {
                    toolCall(name, c.optJSONObject("args") ?: JSONObject())
                } catch (e: Exception) {
                    "Hata: ${e.message}"
                }
                responses.put(JSONObject()
                    .put("id", c.optString("id"))
                    .put("name", name)
                    .put("response", JSONObject().put("result", result)))
            }
            ws?.send(JSONObject().put("toolResponse",
                JSONObject().put("functionResponses", responses)).toString())
        }
    }

    fun sendAudio(pcm: ByteArray) {
        if (!ready) return
        val b64 = Base64.encodeToString(pcm, Base64.NO_WRAP)
        ws?.send(JSONObject().put("realtimeInput", JSONObject().put("audio",
            JSONObject().put("data", b64).put("mimeType", "audio/pcm;rate=16000"))).toString())
    }

    fun sendText(text: String) {
        if (!ready) return
        ws?.send(JSONObject().put("realtimeInput", JSONObject().put("text", text)).toString())
    }

    fun close() {
        ready = false
        ws?.close(1000, "bye")
        ws = null
        http.dispatcher.executorService.shutdown()
    }
}
