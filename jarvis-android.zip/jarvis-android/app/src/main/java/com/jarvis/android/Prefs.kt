package com.jarvis.android

import android.content.Context
import org.json.JSONObject

/** API anahtarı, ses seçimi, kalıcı hafıza ve WhatsApp kişileri. */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    var apiKey: String
        get() = sp.getString("api_key", "") ?: ""
        set(v) = sp.edit().putString("api_key", v.trim()).apply()

    var voice: String
        get() = sp.getString("voice", "Charon") ?: "Charon"
        set(v) = sp.edit().putString("voice", v).apply()

    var model: String
        get() = sp.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL
        set(v) = sp.edit().putString("model", v.trim().ifBlank { DEFAULT_MODEL }).apply()

    // ---- Kalıcı hafıza: { "identity": {"name": "Ali"}, ... } ----
    private fun memoryJson() = JSONObject(sp.getString("memory", "{}") ?: "{}")

    fun saveMemory(category: String, key: String, value: String) {
        val m = memoryJson()
        val cat = m.optJSONObject(category) ?: JSONObject()
        cat.put(key, value)
        m.put(category, cat)
        sp.edit().putString("memory", m.toString()).apply()
    }

    fun deleteMemory(category: String?, key: String?, matchText: String?): Int {
        val m = memoryJson()
        var removed = 0
        val cats = m.keys().asSequence().toList()
        for (c in cats) {
            if (!category.isNullOrBlank() && c != category) continue
            val cat = m.getJSONObject(c)
            for (k in cat.keys().asSequence().toList()) {
                val hitKey = !key.isNullOrBlank() && k == key
                val hitText = !matchText.isNullOrBlank() &&
                    (k.contains(matchText, true) || cat.getString(k).contains(matchText, true))
                if (hitKey || hitText) { cat.remove(k); removed++ }
            }
        }
        sp.edit().putString("memory", m.toString()).apply()
        return removed
    }

    fun memoryAsPromptText(): String {
        val m = memoryJson()
        if (m.length() == 0) return ""
        val sb = StringBuilder("\n\n[KULLANICI HAKKINDA BİLGİLER]\n")
        for (c in m.keys()) {
            val cat = m.getJSONObject(c)
            for (k in cat.keys()) sb.append("- ($c) $k: ${cat.getString(k)}\n")
        }
        return sb.toString()
    }

    // ---- WhatsApp kişileri ----
    fun saveContact(name: String, phone: String) {
        val j = JSONObject(sp.getString("contacts", "{}") ?: "{}")
        j.put(name.lowercase(), phone)
        sp.edit().putString("contacts", j.toString()).apply()
    }

    fun findContact(name: String): String? {
        val j = JSONObject(sp.getString("contacts", "{}") ?: "{}")
        val n = name.lowercase()
        j.optString(n).takeIf { it.isNotBlank() }?.let { return it }
        for (k in j.keys()) if (k.contains(n) || n.contains(k)) return j.getString(k)
        return null
    }
}

const val DEFAULT_MODEL = "gemini-2.5-flash-native-audio-latest"
