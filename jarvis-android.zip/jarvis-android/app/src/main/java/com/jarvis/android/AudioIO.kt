package com.jarvis.android

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import kotlin.concurrent.thread

/** Mikrofon: 16 kHz, mono, 16-bit PCM. Yankı önleme için VOICE_COMMUNICATION kaynağı. */
class MicRecorder(private val onChunk: (ByteArray) -> Unit) {
    @Volatile private var running = false
    private var record: AudioRecord? = null

    @SuppressLint("MissingPermission")
    fun start() {
        if (running) return
        val rate = 16000
        val minBuf = AudioRecord.getMinBufferSize(
            rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val rec = AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION, rate,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
            maxOf(minBuf, 4096)
        )
        record = rec
        running = true
        rec.startRecording()
        thread(name = "mic", isDaemon = true) {
            val buf = ByteArray(2048) // ~64 ms
            while (running) {
                val n = rec.read(buf, 0, buf.size)
                if (n > 0) onChunk(buf.copyOf(n))
            }
        }
    }

    fun stop() {
        running = false
        try { record?.stop() } catch (_: Exception) {}
        record?.release()
        record = null
    }
}

/** Hoparlör: Gemini 24 kHz, mono, 16-bit PCM üretir. */
class SpeakerPlayer {
    private val rate = 24000
    private var track: AudioTrack? = null

    @Synchronized
    fun start() {
        if (track != null) return
        val minBuf = AudioTrack.getMinBufferSize(
            rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            .setAudioFormat(
                AudioFormat.Builder().setSampleRate(rate)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setBufferSizeInBytes(maxOf(minBuf * 4, 48000))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build().also { it.play() }
    }

    @Synchronized
    fun write(pcm: ByteArray) { track?.write(pcm, 0, pcm.size) }

    /** Kullanıcı sözünü kestiğinde kuyruktaki sesi at. */
    @Synchronized
    fun flush() { track?.let { it.pause(); it.flush(); it.play() } }

    @Synchronized
    fun stop() {
        track?.let { try { it.stop() } catch (_: Exception) {}; it.release() }
        track = null
    }
}
